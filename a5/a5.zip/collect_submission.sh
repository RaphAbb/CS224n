rm -f assignment5.zip
zip -r assignment5.zip *.py ./outputs
